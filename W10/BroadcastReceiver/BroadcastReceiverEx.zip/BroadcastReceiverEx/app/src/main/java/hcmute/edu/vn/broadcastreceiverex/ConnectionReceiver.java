package hcmute.edu.vn.broadcastreceiverex;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

public class ConnectionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("hcmute.edu.vn.broadcastreceiverex.SOME_ACTION")){
            Toast.makeText(context, "Received action: " + intent.getAction(), Toast.LENGTH_LONG).show();
        }
        else {
            ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();

            boolean isConnected = networkInfo != null && networkInfo.isConnectedOrConnecting();
            if (isConnected)
            {
                Toast.makeText(context, "Network is connected.", Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(context, "Network is changed or reconnected", Toast.LENGTH_LONG).show();
            }
        }
    }
}
